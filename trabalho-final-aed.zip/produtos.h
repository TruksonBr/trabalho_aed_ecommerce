#ifndef PRODUTOS_H
#define PRODUTOS_H

typedef struct {
    char categoria[50];
    char nome[100];
    char descricao[255];
    float valorUnitario;
    int quantidadeEstoque;
    float notaAvaliacao;
} Produto;

void cadastrarProduto();
void listarProdutos();
void listarProdutosAleatorios();
Produto buscarProduto(char* nome);
void avaliarProduto(char* nome, float nota);

#endif
