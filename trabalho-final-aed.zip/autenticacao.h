#ifndef AUTENTICACAO_H
#define AUTENTICACAO_H

#include "clientes.h"
#include "vendedores.h"

int autenticarCliente(char* usuario, char* senha);
int loginCliente();

int autenticarVendedor(char* cnpj, char* senha);
int loginVendedor();


#endif
