#include "clientes.h"
#include <stdio.h>
#include <string.h>
#include "produtos.h"

Cliente clientes[100];
int contadorClientes = 0;

void cadastrarCliente() {
    Cliente c;
    printf("Nome do Cliente: ");
    scanf("%99s", c.nome);
    printf("Usuário: ");
    scanf("%49s", c.usuario);
    printf("Senha: ");
    scanf("%49s", c.senha);

    clientes[contadorClientes++] = c;
    printf("Cliente cadastrado com sucesso!\n");
}

Cliente buscarClientePorUsuario(char* usuario) {
    for (int i = 0; i < contadorClientes; i++) {
        if (strcmp(clientes[i].usuario, usuario) == 0) {
            return clientes[i];
        }
    }
    Cliente vazio;
    strcpy(vazio.nome, "N/A");
    return vazio; 
}

void submenuCliente() {
    int opcao;
    do {
        printf("\n--- Menu Cliente ---\n");
        printf("1. Listar Produtos\n");
        printf("2. Sair\n");
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                listarProdutos();
                break;
            case 2:
                return; 
            default:
                printf("Opção inválida. Tente novamente.\n");
        }
    } while (opcao != 2);
}
