#include "autenticacao.h"
#include <stdio.h>
#include <string.h>

int autenticarCliente(char* usuario, char* senha) {
    Cliente c = buscarClientePorUsuario(usuario);
    if (strcmp(c.nome, "N/A") != 0 && strcmp(c.senha, senha) == 0) {
        printf("Autenticação bem-sucedida!\n");
        return 1; 
    } else {
        printf("Usuário ou senha inválidos!\n");
        return 0; 
    }
}

int loginCliente() {
    char usuario[50], senha[50];
    printf("Login Cliente\n");
    printf("Usuário: ");
    scanf("%49s", usuario);
    printf("Senha: ");
    scanf("%49s", senha);

    int resultado = autenticarCliente(usuario, senha);

    if (resultado == 1) {
        printf("Login bem-sucedido. Bem-vindo(a), %s!\n", usuario);
        return 1; 
    } else {
        printf("Falha no login.\n");
        return 0; 
    }
}

int autenticarVendedor(char* cnpj, char* senha) {
    Vendedor vendedor = buscarVendedorPorCNPJ(cnpj);
    if (strcmp(vendedor.nome, "N/A") != 0 && strcmp(vendedor.senha, senha) == 0) {
         printf("Autenticação bem-sucedida!\n");
        return 1; 
    } else {
        printf("Usuário ou senha inválidos!\n");
        return 0; 
    }
}

int loginVendedor() {
    char cnpj[15]; 
    char senha[51]; 
    
    printf("Login de Vendedor\n");
    printf("Digite o CNPJ: ");
    scanf("%14s", cnpj); 
    getchar(); 
    printf("Digite a senha: ");
    scanf("%50s", senha); 
    if (autenticarVendedor(cnpj, senha)) {
        printf("Login bem-sucedido!\n");
        return 1; 
    } else {
        printf("Falha no login. CNPJ ou senha incorretos.\n");
        return 0; 
    }
}