#ifndef VENDEDORES_H
#define VENDEDORES_H

typedef struct {
    char nome[100];
    char cnpj[14];
    char senha[50];
} Vendedor;

void cadastrarVendedor();
Vendedor buscarVendedorPorCNPJ(char* cnpj);



void submenuVendedor();

#endif
