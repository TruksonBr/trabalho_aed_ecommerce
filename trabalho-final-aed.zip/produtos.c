#include "produtos.h"
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

int contadorProdutos = 0;
Produto produtos[100];


void cadastrarProduto() {
    Produto p;
    printf("Categoria do Produto: ");
    scanf("%49s", p.categoria);
    printf("Nome do Produto: ");
    scanf("%99s", p.nome);
    printf("Descrição do Produto: ");
    scanf("%254s", p.descricao);
    printf("Valor Unitário: ");
    scanf("%f", &p.valorUnitario);
    printf("Quantidade em Estoque: ");
    scanf("%d", &p.quantidadeEstoque);
    p.notaAvaliacao = 0; 

    produtos[contadorProdutos++] = p;
    printf("Produto cadastrado com sucesso!\n");
}


void listarProdutos() {
    printf("Produtos cadastrados:\n");
    for (int i = 0; i < contadorProdutos; i++) {
        printf("%d. %s - %s\n", i + 1, produtos[i].nome, produtos[i].descricao);
    }
}

void listarProdutosAleatorios() {
    printf("Produtos recomendados:\n");
    
    srand(time(NULL));
    for (int i = 0; i < 5; i++) {
        int indiceAleatorio = rand() % contadorProdutos;
        printf("%d. %s - %s\n", i + 1, produtos[indiceAleatorio].nome, produtos[indiceAleatorio].descricao);
    }
}

Produto buscarProduto(char* nome) {
    for (int i = 0; i < contadorProdutos; i++) {
        if (strcmp(produtos[i].nome, nome) == 0) {
            return produtos[i];
        }
    }
    Produto vazio; 
    strcpy(vazio.nome, "Produto não encontrado");
    return vazio;
}

void avaliarProduto(char* nome, float nota) {
    for (int i = 0; i < contadorProdutos; i++) {
        if (strcmp(produtos[i].nome, nome) == 0) {
            produtos[i].notaAvaliacao = nota;
            printf("Produto '%s' avaliado com nota %.1f.\n", nome, nota);
            return;
        }
    }
    printf("Produto não encontrado para avaliação.\n");
}

