#include <stdio.h>
#include "vendedores.h"
#include "clientes.h"
#include "autenticacao.h"
#include "produtos.h"

void menuPrincipal();



int main() {
    menuPrincipal();
    return 0;
}

void menuPrincipal() {
    int opcao;
    int loginResult;
    do {
        printf("\n-------- Sistema --------\n");
        printf("1. Cadastrar Vendedor\n");
        printf("2. Cadastrar Cliente\n");
        printf("3. Login Cliente\n");
        printf("4. Login Vendedor\n");
        printf("5. Sair\n\n");
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                cadastrarVendedor();
                break;
            case 2:
                cadastrarCliente();
                break;
            case 3:
                loginResult = loginCliente(); 
                if (loginResult == 1) {
                    submenuCliente();
                }
                break;
            case 4:
                loginResult = loginVendedor(); 
                if (loginResult == 1) {
                    submenuVendedor();
                }
                break;
            case 5:
                printf("Saindo...\n");
                break;
            default:
                printf("Opção inválida. Tente novamente.\n");
        }
    } while (opcao != 5);
}




