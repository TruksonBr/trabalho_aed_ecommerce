#ifndef CLIENTES_H
#define CLIENTES_H

typedef struct {
    char nome[100];
    char usuario[50];
    char senha[50];
} Cliente;

void cadastrarCliente();
Cliente buscarClientePorUsuario(char* usuario);

void submenuCliente();
#endif
