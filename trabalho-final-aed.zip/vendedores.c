#include "vendedores.h"
#include <stdio.h>
#include <string.h>
#include "produtos.h"

Vendedor vendedores[100];
int contadorVendedores = 0;

void cadastrarVendedor() {
    Vendedor v;
    printf("Nome do Vendedor/Loja: ");
    scanf("%99s", v.nome);
    printf("CNPJ: ");
    scanf("%14s", v.cnpj);
    printf("Senha: ");
    scanf("%11s", v.senha);

    vendedores[contadorVendedores++] = v;
    printf("Vendedor cadastrado com sucesso!\n");
}

Vendedor buscarVendedorPorCNPJ(char* cnpj) {
    for (int i = 0; i < contadorVendedores; i++) {
        if (strcmp(vendedores[i].cnpj, cnpj) == 0) {
            return vendedores[i];
        }
    }
    Vendedor vazio;
    strcpy(vazio.nome, "N/A"); 
    strcpy(vazio.cnpj, "");    
    strcpy(vazio.senha, "");   
    return vazio;
}


void submenuVendedor() {
    int opcao;
    do {
        printf("\n--- Menu Vendedor ---\n");
        printf("1. Cadastrar Produto\n");
        printf("2. Listar Produtos\n");
        printf("3. Sair\n");
        printf("Escolha uma opção: ");
        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                cadastrarProduto();
                break;
            case 2:
                listarProdutos();
                break;
            case 3:
                return; 
            default:
                printf("Opção inválida. Tente novamente.\n");
        }
    } while (opcao != 3);
}